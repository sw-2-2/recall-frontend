# USER-001 회원가입

## 1. 기본 정보

| 항목 | 내용 |
| --- | --- |
| Method | `POST` |
| Endpoint | `/api/users` 또는 `/api/users/signup` |
| 기능 | 회원가입 |
| 인증 | 원본 표기상 필요, 실제 적용 여부 확인 필요 |
| Content-Type | `application/json` |
| Request Body Type | `JSON Object` |
| Response Body Type | `JSON Object` |
| API 담당자 | 안승우 |
| 구현 상태 | 메인 미반영 |
| 연동 상태 | 시작 전 |

## 2. 기능 설명

신규 사용자를 회원가입 처리합니다. 원본 문서에는 OAuth 도입 전/후 요청 스키마가 모두 존재합니다.

## 3. 요청 명세

### 3.1 Header

| Header | 필수 | 값 |
| --- | --- | --- |
| `Content-Type` | Y | `application/json` |
| `Authorization` | 확인 필요 | `Bearer {accessToken}` |

### 3.2 Request Body: OAuth 도입 전

| 필드명 | 타입 | 필수 | 설명 |
| --- | --- | --- | --- |
| `email` | string | Y | 이메일 |
| `name` | string | Y | 사용자 이름, 최대 20자 |
| `phone` | string | N | 휴대폰 번호, 최대 11자, 공백 없음 |
| `address` | string | N | 주소 |

### 3.3 Request Body: OAuth 도입 후

| 필드명 | 타입 | 필수 | 설명 |
| --- | --- | --- | --- |
| `provider` | string | Y | 원본 기준 `KAKAO` |
| `providerId` | long | Y | OAuth 제공자 사용자 ID |
| `name` | string | Y | 사용자 이름, 최대 20자 |
| `phone` | string | N | 휴대폰 번호, 최대 11자, 공백 없음 |
| `address` | string | N | 주소 |

### 3.4 Request Example

```json
{
  "email": "test@gmail.com",
  "name": "홍길동",
  "phone": "01012345678"
}
```

## 4. 응답 명세

| 필드명 | 타입 | 필수 | 설명 |
| --- | --- | --- | --- |
| `id` | long | Y | 사용자 ID |
| `email` | string | Y | 사용자 이메일 |
| `name` | string | Y | 사용자 이름 |
| `createdAt` | DateTime | Y | 생성일시 |

### 4.1 Response Example

```json
{
  "id": 1,
  "email": "test@gmail.com",
  "name": "홍길동",
  "createdAt": "2026-03-11T12:30:00Z"
}
```

## 5. 연동 메모

1. 문서 제목은 `/api/users`, 상세 설계는 `/api/users/signup`으로 표기되어 있어 실제 경로 확정이 필요합니다.
2. 회원가입 API에 `BearerAuth`가 표기되어 있으나 일반적인 인증 흐름과 상충합니다.
3. 공통 에러 포맷은 [공통 - 에러 응답.md](./공통%20-%20에러%20응답.md)를 참조합니다.
