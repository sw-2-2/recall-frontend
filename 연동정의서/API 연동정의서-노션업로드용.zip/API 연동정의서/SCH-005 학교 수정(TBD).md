# SCH-005 학교 수정(TBD)

## 1. 기본 정보

| 항목 | 내용 |
| --- | --- |
| Method | `PUT` |
| Endpoint | `/api/v1/schools` |
| 기능 | 학교 정보 수정 |
| 인증 | TBD |
| Content-Type | `application/json` |
| Request Body Type | `TBD` |
| Response Body Type | `TBD` |
| 구현 상태 | 추후 |
| 연동 상태 | 시작 전 |

## 2. 기능 설명

원본 문서에는 제목과 기능 설명만 존재하며 상세 스펙은 정의되지 않았습니다.

## 3. 추가 정의 필요 항목

1. Path Variable 또는 Request Body 구조
2. 수정 대상 식별 방식
3. 인증 필요 여부
4. 응답 스키마
5. 호출 주체와 사용 화면

## 4. 연동 메모

1. 백엔드 스펙 확정 전까지 프론트 구현 대상에서 제외하는 편이 안전합니다.
2. 공통 에러 포맷은 [공통 - 에러 응답.md](./공통%20-%20에러%20응답.md)를 참조합니다.
