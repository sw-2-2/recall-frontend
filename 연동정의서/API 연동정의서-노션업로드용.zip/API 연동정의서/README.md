# API 연동정의서 목록

원본 `API 명세서`를 기준으로 엔드포인트별 개별 연동정의서 문서를 재구성했습니다.

## 공통 문서

| 문서 | 설명 |
| --- | --- |
| [공통 - 에러 응답.md](./공통%20-%20에러%20응답.md) | 전 API 공통 에러 응답 형식 |

## 인증

| ID | 문서 | 비고 |
| --- | --- | --- |
| AUTH-001 | [AUTH-001 OAuth 인증.md](./AUTH-001%20OAuth%20인증.md) | OAuth 인증 및 토큰 발급 |
| AUTH-002 | [AUTH-002 토큰 재발급.md](./AUTH-002%20토큰%20재발급.md) | Refresh Token 기반 재발급 |

## 회원

| ID | 문서 | 비고 |
| --- | --- | --- |
| USER-001 | [USER-001 회원가입.md](./USER-001%20회원가입.md) | `/api/users` 와 `/api/users/signup` 표기 충돌 |
| USER-002 | [USER-002 로그인.md](./USER-002%20로그인.md) | 인증 헤더 표기 확인 필요 |
| USER-003 | [USER-003 회원정보 조회.md](./USER-003%20회원정보%20조회.md) | 프로필 조회 |
| USER-004 | [USER-004 회원정보 수정.md](./USER-004%20회원정보%20수정.md) | 전체 교체 방식 |
| USER-005 | [USER-005 학교 생성 후 연결.md](./USER-005%20학교%20생성%20후%20연결.md) | 신규 학교 생성 후 사용자 연결 |
| USER-006 | [USER-006 기존 학교 연결.md](./USER-006%20기존%20학교%20연결.md) | 기존 학교 선택 연결 |
| USER-007 | [USER-007 본인 학교 정보 조회.md](./USER-007%20본인%20학교%20정보%20조회.md) | 실제 Path 표기 충돌 |
| USER-008 | [USER-008 회원 등록(TBD).md](./USER-008%20회원%20등록(TBD).md) | placeholder 문서 기반, 정식 반영 필요 |

## 학교

| ID | 문서 | 비고 |
| --- | --- | --- |
| SCH-001 | [SCH-001 학교 리스트 조회.md](./SCH-001%20학교%20리스트%20조회.md) | `keyword` 없는 목록 조회 |
| SCH-002 | [SCH-002 학교 검색 조회.md](./SCH-002%20학교%20검색%20조회.md) | `keyword` 필수 |
| SCH-003 | [SCH-003 학교 상세 조회.md](./SCH-003%20학교%20상세%20조회.md) | 학교 기본 정보 조회 |
| SCH-004 | [SCH-004 학교 멤버 조회.md](./SCH-004%20학교%20멤버%20조회.md) | Bearer 적용 메모 존재 |
| SCH-005 | [SCH-005 학교 수정(TBD).md](./SCH-005%20학교%20수정(TBD).md) | 상세 정의 없음 |

## 확인 필요

1. `POST /api/users` 문서의 상세 경로가 `/api/users/signup`으로 표기되어 있습니다.
2. `GET /api/users/schools/{type}` 문서의 상세 경로가 `/api/users/schools`로 표기되어 있습니다.
3. `POST /api/users`, `POST /api/users/login`에 `BearerAuth`가 표기되어 있으나 인증 흐름과 상충합니다.
4. `/api/users/register` 관련 문서는 목록 문서에 반영되지 않은 placeholder 상태입니다.
