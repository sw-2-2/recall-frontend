# USER-005 학교 생성 후 연결

## 1. 기본 정보

| 항목 | 내용 |
| --- | --- |
| Method | `POST` |
| Endpoint | `/api/users/schools/{type}/new` |
| 기능 | 신규 학교 생성 후 현재 사용자와 연결 |
| 인증 | 필요 |
| Content-Type | `application/json` |
| Request Body Type | `JSON Object` |
| Response Body Type | `JSON Object` |
| API 담당자 | 안승우 |
| 구현 상태 | 시작 전 |
| 연동 상태 | 시작 전 |

## 2. 기능 설명

신규 학교를 등록한 뒤, 해당 학교를 현재 사용자와 연결합니다.

## 3. 요청 명세

### 3.1 Header

| Header | 필수 | 값 |
| --- | --- | --- |
| `Content-Type` | Y | `application/json` |
| `Authorization` | Y | `Bearer {accessToken}` |

### 3.2 Path Parameter

| 필드명 | 타입 | 필수 | 설명 |
| --- | --- | --- | --- |
| `type` | string | Y | 학교 유형. `elementary`, `middle`, `high` |

### 3.3 Request Body

| 필드명 | 타입 | 필수 | 설명 |
| --- | --- | --- | --- |
| `name` | string | Y | 학교 이름, 최대 30자 |
| `address` | string | N | 학교 주소 |
| `graduationYear` | int | Y | 졸업년도 |

### 3.4 Request Example

```json
{
  "name": "서울고등학교",
  "address": "서울시 서초구",
  "graduationYear": 2018
}
```

## 4. 응답 명세

| 필드명 | 타입 | 필수 | 설명 |
| --- | --- | --- | --- |
| `id` | long | Y | 등록한 학교 ID |
| `type` | string | Y | 학교 유형 |
| `graduationYear` | int | Y | 졸업년도 |
| `name` | string | Y | 학교 이름 |
| `imageUrl` | string | N | 학교 대표 이미지 |
| `address` | string | Y | 학교 주소 |
| `createdAt` | DateTime | Y | 생성일시 |

### 4.1 Response Example

```json
{
  "id": 101,
  "type": "high",
  "graduationYear": 2018,
  "name": "서울고등학교",
  "imageUrl": "https://example.com/schools/101.png",
  "address": "서울시 서초구",
  "createdAt": "2026-03-11T12:30:00Z"
}
```

## 5. 연동 메모

1. 검색 결과에 학교가 없을 때 신규 등록 플로우에서 사용합니다.
2. 공통 에러 포맷은 [공통 - 에러 응답.md](./공통%20-%20에러%20응답.md)를 참조합니다.
