# AUTH-002 토큰 재발급

## 1. 기본 정보

| 항목 | 내용 |
| --- | --- |
| Method | `POST` |
| Endpoint | `/api/auth/refresh` |
| 기능 | Refresh Token 기반 Access Token 재발급 |
| 인증 | 불필요 |
| Content-Type | `application/json` |
| Request Body Type | `JSON Object` |
| Response Body Type | `JSON Object` |
| 구현 상태 | 추후 |
| 연동 상태 | 시작 전 |

## 2. 기능 설명

Refresh Token을 사용해 Access Token을 재발급합니다.

## 3. 요청 명세

### 3.1 Header

| Header | 필수 | 값 |
| --- | --- | --- |
| `Content-Type` | Y | `application/json` |

### 3.2 Request Body

| 필드명 | 타입 | 필수 | 설명 |
| --- | --- | --- | --- |
| `refreshToken` | string | Y | Access Token 갱신용 Refresh Token |

### 3.3 Request Example

```json
{
  "refreshToken": "ey..."
}
```

## 4. 응답 명세

### 4.1 Response Body

| 필드명 | 타입 | 필수 | 설명 |
| --- | --- | --- | --- |
| `accessToken` | string | Y | 신규 Access Token |
| `expiresIn` | integer | Y | Access Token 만료 시간(초) |
| `tokenType` | string | Y | 토큰 타입. 원본 기준 `Bearer` |

### 4.2 Response Example

```json
{
  "accessToken": "ey...",
  "expiresIn": 6000,
  "tokenType": "Bearer"
}
```

## 5. 연동 메모

1. `401 Unauthorized` 응답 수신 시 1회 재발급 후 원 요청 재시도 전략을 권장합니다.
2. 공통 에러 포맷은 [공통 - 에러 응답.md](./공통%20-%20에러%20응답.md)를 참조합니다.
