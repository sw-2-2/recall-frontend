# USER-007 본인 학교 정보 조회

## 1. 기본 정보

| 항목 | 내용 |
| --- | --- |
| Method | `GET` |
| Endpoint | `/api/users/schools/{type}` |
| 기능 | 현재 사용자의 학교 기본 정보 조회 |
| 인증 | 필요 |
| Content-Type | `application/json` |
| Response Body Type | `JSON Object` |
| API 담당자 | 차가민 |
| 구현 상태 | 시작 전 |
| 연동 상태 | 시작 전 |

## 2. 기능 설명

메인 화면에서 사용자의 학교 기본 정보를 조회합니다.

## 3. 요청 명세

### 3.1 Header

| Header | 필수 | 값 |
| --- | --- | --- |
| `Authorization` | Y | `Bearer {accessToken}` |

### 3.2 Path Parameter

| 필드명 | 타입 | 필수 | 설명 | 기본값 |
| --- | --- | --- | --- | --- |
| `type` | string | Y | 학교 유형. `elementary`, `middle`, `high` | `elementary` |

## 4. 응답 명세

| 필드명 | 타입 | 필수 | 설명 |
| --- | --- | --- | --- |
| `id` | long | Y | 학교 ID |
| `name` | string | Y | 학교 이름 |
| `type` | string | Y | 학교 유형 |
| `imageUrl` | string | N | 학교 대표 이미지 |
| `address` | string | N | 학교 주소 |

### 4.1 Response Example

```json
{
  "id": 101,
  "name": "서울고등학교",
  "type": "high",
  "imageUrl": "https://example.com/schools/101.png",
  "address": "서울시 서초구"
}
```

## 5. 연동 메모

1. 원본 상세 문서의 API Path는 `/api/users/schools`로 표기되어 있어 실제 경로 확정이 필요합니다.
2. 공통 에러 포맷은 [공통 - 에러 응답.md](./공통%20-%20에러%20응답.md)를 참조합니다.
