# USER-003 회원정보 조회

## 1. 기본 정보

| 항목 | 내용 |
| --- | --- |
| Method | `GET` |
| Endpoint | `/api/users/me` |
| 기능 | 프로필 회원정보 조회 |
| 인증 | 필요 |
| Content-Type | `application/json` |
| Response Body Type | `JSON Object` |
| API 담당자 | 안승우 |
| 구현 상태 | 메인 미반영 |
| 연동 상태 | 시작 전 |

## 2. 기능 설명

프로필 페이지에서 회원 기본 정보와 연결된 학교 목록을 조회합니다.

## 3. 요청 명세

### 3.1 Header

| Header | 필수 | 값 |
| --- | --- | --- |
| `Authorization` | Y | `Bearer {accessToken}` |

### 3.2 Query Parameter

없음

## 4. 응답 명세

### 4.1 Response Body

| 필드명 | 타입 | 필수 | 설명 |
| --- | --- | --- | --- |
| `id` | long | Y | 사용자 ID |
| `email` | string | Y | 사용자 이메일 |
| `name` | string | Y | 사용자 이름 |
| `phone` | string | N | 휴대폰 번호 |
| `address` | string | N | 주소 |
| `createdAt` | DateTime | Y | 생성일시 |
| `schools` | List | Y | 연결된 학교 목록 |

`schools` 객체

| 필드명 | 타입 | 필수 | 설명 |
| --- | --- | --- | --- |
| `id` | long | Y | 등록한 학교 ID |
| `type` | string | Y | 학교 유형 |
| `graduationYear` | int | Y | 졸업년도 |
| `name` | string | Y | 학교 이름 |
| `imageUrl` | string | N | 학교 대표 이미지 |
| `address` | string | Y | 학교 주소 |
| `createdAt` | DateTime | Y | 생성일시 |

### 4.2 Response Example

```json
{
  "id": 1,
  "email": "test@gmail.com",
  "name": "홍길동",
  "phone": "01012345678",
  "address": "서울시 강남구",
  "createdAt": "2026-03-11T12:30:00Z",
  "schools": [
    {
      "id": 101,
      "type": "high",
      "graduationYear": 2018,
      "name": "서울고등학교",
      "imageUrl": "https://example.com/schools/101.png",
      "address": "서울시 서초구",
      "createdAt": "2026-03-11T12:30:00Z"
    }
  ]
}
```

## 5. 연동 메모

1. 화면 진입 시 사용자 프로필 초기 데이터 조회용으로 사용합니다.
2. 공통 에러 포맷은 [공통 - 에러 응답.md](./공통%20-%20에러%20응답.md)를 참조합니다.
