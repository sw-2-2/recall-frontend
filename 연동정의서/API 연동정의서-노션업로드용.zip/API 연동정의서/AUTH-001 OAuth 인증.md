# AUTH-001 OAuth 인증

## 1. 기본 정보

| 항목 | 내용 |
| --- | --- |
| Method | `POST` |
| Endpoint | `/api/auth/oauth/{provider}` |
| 기능 | OAuth 인증 및 서비스 토큰 발급 |
| 인증 | 불필요 |
| Content-Type | `application/json` |
| Request Body Type | `JSON Object` |
| Response Body Type | `JSON Object` |
| 구현 상태 | 추후 |
| 연동 상태 | 시작 전 |

## 2. 기능 설명

OAuth 제공자로부터 받은 인증 코드로 사용자 정보를 조회하고, 서비스에서 사용할 `accessToken`과 `refreshToken`을 발급합니다.

## 3. 요청 명세

### 3.1 Header

| Header | 필수 | 값 |
| --- | --- | --- |
| `Content-Type` | Y | `application/json` |

### 3.2 Path Parameter

| 필드명 | 타입 | 필수 | 설명 |
| --- | --- | --- | --- |
| `provider` | string | Y | OAuth 제공자. 원본 기준 `kakao` |

### 3.3 Request Body

| 필드명 | 타입 | 필수 | 설명 |
| --- | --- | --- | --- |
| `code` | string | Y | OAuth 제공자로부터 전달받은 인증 코드 |
| `redirectUri` | string | Y | 인증 코드 발급 시 사용한 Redirect URI |

### 3.4 Request Example

```json
{
  "code": "ey...",
  "redirectUri": "https://example.com/oauth/callback"
}
```

## 4. 응답 명세

### 4.1 Response Body

| 필드명 | 타입 | 필수 | 설명 |
| --- | --- | --- | --- |
| `accessToken` | string | Y | API 요청용 JWT Access Token |
| `refreshToken` | string | Y | Access Token 재발급용 Refresh Token |
| `expiresIn` | integer | Y | Access Token 만료 시간(초) |
| `tokenType` | string | Y | 토큰 타입. 원본 기준 `Bearer` |
| `user` | object | Y | OAuth 사용자 정보 |

`user` 객체

| 필드명 | 타입 | 필수 | 설명 |
| --- | --- | --- | --- |
| `oauthId` | string | Y | OAuth 제공자 사용자 ID |
| `provider` | string | Y | OAuth 제공자 |
| `email` | string | Y | OAuth 제공 이메일 |
| `name` | string | N | OAuth 제공 이름 |
| `isRegistered` | boolean | Y | 서비스 회원 등록 여부 |

### 4.2 Response Example

```json
{
  "accessToken": "ey...",
  "refreshToken": "ey...",
  "expiresIn": 6000,
  "tokenType": "Bearer",
  "user": {
    "oauthId": "oauth-user-id",
    "provider": "kakao",
    "email": "test@gmail.com",
    "name": "홍길동",
    "isRegistered": false
  }
}
```

## 5. 연동 메모

1. `user.isRegistered`가 `false`이면 추가 회원 등록 절차가 필요합니다.
2. 후속 회원 등록 API는 원본 문서 기준 `/api/users`, `/api/users/signup`, `/api/users/register`가 혼재되어 있어 확인이 필요합니다.
3. 공통 에러 포맷은 [공통 - 에러 응답.md](./공통%20-%20에러%20응답.md)를 참조합니다.
