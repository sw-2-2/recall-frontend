# USER-008 회원 등록(TBD)

## 1. 기본 정보

| 항목 | 내용 |
| --- | --- |
| Method | `POST` |
| Endpoint | `/api/users/register` |
| 기능 | OAuth 인증 완료 사용자의 추가 회원 등록 |
| 인증 | 필요 |
| Content-Type | `application/json` |
| Request Body Type | `JSON Object` |
| Response Body Type | `JSON Object` |
| 구현 상태 | 추후 |
| 연동 상태 | 시작 전 |

## 2. 기능 설명

placeholder 문서 기준으로, OAuth 인증이 끝난 사용자의 추가 정보를 등록하는 API로 보입니다. 목록 문서에는 정식 반영되지 않았습니다.

## 3. 요청 명세

### 3.1 Header

| Header | 필수 | 값 |
| --- | --- | --- |
| `Content-Type` | Y | `application/json` |
| `Authorization` | Y | `Bearer {accessToken}` |

### 3.2 Request Body

| 필드명 | 타입 | 필수 | 설명 |
| --- | --- | --- | --- |
| `userType` | string | Y | 사용자 유형 |
| `nickname` | string | Y | 별명, 최대 32자 |

### 3.3 Request Example

```json
{
  "userType": "student",
  "nickname": "홍길동"
}
```

## 4. 응답 명세

| 필드명 | 타입 | 필수 | 설명 |
| --- | --- | --- | --- |
| `userType` | string | Y | 사용자 유형 |
| `nickname` | string | Y | 별명 |

### 4.1 Response Example

```json
{
  "userType": "student",
  "nickname": "홍길동"
}
```

## 5. 연동 메모

1. 원본 파일명이 `제목 없음`이며 목록 문서에 없으므로 정식 API 채택 여부를 확인해야 합니다.
2. `AUTH-001 OAuth 인증` 이후 `isRegistered=false` 사용자용 후속 API일 가능성이 높습니다.
3. 공통 에러 포맷은 [공통 - 에러 응답.md](./공통%20-%20에러%20응답.md)를 참조합니다.
