# USER-004 회원정보 수정

## 1. 기본 정보

| 항목 | 내용 |
| --- | --- |
| Method | `PUT` |
| Endpoint | `/api/users/me` |
| 기능 | 프로필 회원정보 수정 |
| 인증 | 필요 |
| Content-Type | `application/json` |
| Request Body Type | `JSON Object` |
| Response Body Type | `JSON Object` |
| API 담당자 | 안승우 |
| 구현 상태 | 메인 미반영 |
| 연동 상태 | 시작 전 |

## 2. 기능 설명

프로필 페이지에서 회원 정보를 수정합니다. 원본 문서 기준 부분 수정이 아니라 전달한 Body 기준 전체 교체입니다.

## 3. 요청 명세

### 3.1 Header

| Header | 필수 | 값 |
| --- | --- | --- |
| `Content-Type` | Y | `application/json` |
| `Authorization` | Y | `Bearer {accessToken}` |

### 3.2 Request Body

| 필드명 | 타입 | 필수 | 설명 |
| --- | --- | --- | --- |
| `name` | string | Y | 사용자 이름, 최대 20자 |
| `phone` | string | N | 휴대폰 번호, 최대 11자 |
| `address` | string | N | 주소 |

### 3.3 Request Example

```json
{
  "name": "홍길동",
  "phone": "01012345678",
  "address": "서울시 강남구"
}
```

## 4. 응답 명세

| 필드명 | 타입 | 필수 | 설명 |
| --- | --- | --- | --- |
| `id` | long | Y | 사용자 ID |
| `name` | string | Y | 사용자 이름 |
| `phone` | string | N | 휴대폰 번호 |
| `address` | string | N | 주소 |
| `updatedAt` | DateTime | Y | 수정일시 |

### 4.1 Response Example

```json
{
  "id": 1,
  "name": "홍길동",
  "phone": "01012345678",
  "address": "서울시 강남구",
  "updatedAt": "2026-03-11T12:30:00Z"
}
```

## 5. 연동 메모

1. 수정 화면에서는 일부 필드만 보낸다고 가정하지 말고, 서버가 요구하는 전체 Body를 맞춰 보내는 방식으로 처리해야 합니다.
2. 공통 에러 포맷은 [공통 - 에러 응답.md](./공통%20-%20에러%20응답.md)를 참조합니다.
