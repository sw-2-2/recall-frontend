# USER-002 로그인

## 1. 기본 정보

| 항목 | 내용 |
| --- | --- |
| Method | `POST` |
| Endpoint | `/api/users/login` |
| 기능 | 로그인 |
| 인증 | 원본 표기상 필요, 실제로는 불필요할 가능성 높음 |
| Content-Type | `application/json` |
| Request Body Type | `JSON Object` |
| Response Body Type | `JSON Object` |
| 구현 상태 | 시작 전 |
| 연동 상태 | 시작 전 |

## 2. 기능 설명

사용자 로그인 후 `accessToken`, `refreshToken`을 발급합니다. 원본 문서에는 OAuth 도입 전/후 요청 스키마가 분리되어 있습니다.

## 3. 요청 명세

### 3.1 Header

| Header | 필수 | 값 |
| --- | --- | --- |
| `Content-Type` | Y | `application/json` |
| `Authorization` | 확인 필요 | `Bearer {accessToken}` |

### 3.2 Request Body: OAuth 도입 전

| 필드명 | 타입 | 필수 | 설명 |
| --- | --- | --- | --- |
| `email` | string | Y | 이메일 |
| `password` | string | Y | 비밀번호 |

Request Example

```json
{
  "email": "test@gmail.com",
  "password": "password1234"
}
```

### 3.3 Request Body: OAuth 도입 후

| 필드명 | 타입 | 필수 | 설명 |
| --- | --- | --- | --- |
| `provider` | string | Y | 원본 기준 `KAKAO` |
| `oauthToken` | string | Y | OAuth 제공자가 발급한 인증 토큰 |
| `providerId` | long | Y | OAuth 제공자 사용자 ID |

Request Example

```json
{
  "provider": "KAKAO",
  "oauthToken": "oauth-token",
  "providerId": 123456789
}
```

## 4. 응답 명세

| 필드명 | 타입 | 필수 | 설명 |
| --- | --- | --- | --- |
| `accessToken` | string | Y | JWT Access Token |
| `refreshToken` | string | Y | JWT Refresh Token |

### 4.1 Response Example

```json
{
  "accessToken": "ey...",
  "refreshToken": "ey..."
}
```

## 5. 연동 메모

1. 로그인 API에 `Authorization: BearerAuth`가 표기되어 있으나 실제 적용 여부 확인이 필요합니다.
2. OAuth 로그인은 `POST /api/auth/oauth/{provider}`와 역할이 중복될 수 있어 로그인 플로우 정리가 필요합니다.
3. 공통 에러 포맷은 [공통 - 에러 응답.md](./공통%20-%20에러%20응답.md)를 참조합니다.
